/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ruan_a_alves
 */
public class EX1 {

    public static void main(String arg[]) {
        int numero = 16;

        for (int i = 16; i <= 24; i++) {
            if ((i % 2) == 0) {
                System.out.println(i++);
            }
        }

        System.out.println("------------------------");

        while (numero <= 24) {
            if (numero % 2 == 0) {
                System.out.println(numero);
            }
            numero += 2;
        }

    }
}
