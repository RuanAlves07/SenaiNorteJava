/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ruan_a_alves
 */
public class EX1 {

    public static void main(String arg[]) {
        int numero = 15;
        int i = 15;
        int numero2 = 0;

        for (i = 16; i <= 25; i++) {
            if ((numero2 % 2) == 0) {
                System.out.println(i++);
            }
        }

        System.out.println("------------------------");

        while (numero <= 24) {
            numero++;
            if (numero % 2 == 0) {
                System.out.println(numero++);
            }
        }

    }
}
