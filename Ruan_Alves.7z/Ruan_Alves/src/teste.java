
import java.util.Scanner;

public class teste {

    public static void main(String args[]) {
        Scanner imput = new Scanner(System.in);

  int fatorial = 1;
        
    System.out.print("Insira seu numero: ");
    int m = imput.nextInt();
    System.out.println("");
                        
    for (int i = 1; i <= m; i++) {        
        fatorial *= i;    
                System.out.println(i);
                
               if(i < m){
                   System.out.println(" * "); 
               } else {
                   System.out.println(" = " + fatorial);
               }
        
    }
       

            
        }
}