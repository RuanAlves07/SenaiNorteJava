/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ruan_a_alves
 */
public class EX7 {

    public static void main(String[] args) {
        int soma = 0;

        for (int i = 100; i <= 200; i++) {
            if (i % 2 == 0) {
                soma += i;
            }
        }
        System.out.println("Soma dos números: " + soma);

        int somaWhile = 0;
        int i = 100;
        while (i <= 200) {
            if (i % 2 == 0) {
                somaWhile += i;
            }
            i++;

        }
        System.out.println("Soma dos números: " + somaWhile);

    }

}
