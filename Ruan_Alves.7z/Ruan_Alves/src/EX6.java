/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ruan_a_alves
 */
public class EX6 {

    public static void main(String[] args) {
        for (int i = 6; i < 120; i += 6) {
            System.out.println(i);
        }

        System.out.println("--------------");

        int i = 6;
        while (i < 120) {
            System.out.println(i);
            i += 6;
        }
    }

}
