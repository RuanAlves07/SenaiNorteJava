
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author ruan_a_alves
 */
public class EX2 {

    public static void main(String arg[]) {
        Scanner input = new Scanner(System.in);
        int resultado = 1;
        int i = 1;
        int fatorial = 1;

        System.out.println("Digite o número que deseja fatorar: ");
        resultado = input.nextInt();

        while (i <= resultado) {
            fatorial = fatorial * i;
            i++;
        }

        System.out.println("O fatorial do número " + resultado + " é de " + fatorial);
    
        System.out.println("-----------------");
                
                
    }
}
