
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author ruan_a_alves
 */
public class EX3 {

    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);

        
        System.out.println("Seja bem vindo! Primeiramente, me informe o seu nome: ");
        String nome = input.nextLine();
        
        System.out.println("Digite o número de vendas: ");
        int numVendas = input.nextInt();
        double totalVendas = 0;
        
        int cont = 1;
        while (cont <= numVendas) {
            System.out.println("Valor da venda "+ cont + ": ");
            totalVendas += input.nextDouble();
            cont++;
        }
        
        System.out.println("");
        System.out.println("Apresentando relatório:");
        System.out.println("Vendedor: " + nome);
        System.out.println("Total de vendas do vendedor: " + totalVendas);
        System.out.println("Comissão sobre vendas (25%) : R$ " + totalVendas * 0.25);
     
        

    }
}
