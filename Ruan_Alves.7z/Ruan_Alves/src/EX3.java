
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author ruan_a_alves
 */
public class EX3 {

    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        int nome;
        int total = 1;
        
        System.out.println("Seja bem vindo! Primeiramente, me informe o seu nome: ");
        nome = input.nextInt();
        
        for(int vendas = 1; vendas <= total; total++){
        total = (int) (vendas * 0.25);
        total++;
        }
        System.out.println("Total de vendas deu: "+total);
        

    }
}
