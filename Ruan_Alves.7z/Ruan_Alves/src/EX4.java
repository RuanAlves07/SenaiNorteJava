/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ruan_a_alves
 */
public class EX4 {

    public static void main(String[] args) {
        int somaFor = 0;
        for (int i = 1; i <= 100; i++) {
            somaFor += i;
        }
        System.out.println("soma dos números : " + somaFor);

        System.out.println("-----------------------");

        int somaWhile = 0;
        int i = 1;
        while (i <= 100) {
            somaWhile += i;
            i++;
        }

        System.out.println("Soma dos números : " + somaWhile);
    }

}
