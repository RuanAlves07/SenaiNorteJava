
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ruan_a_alves
 */
public class Exercicio5 {
public static void main(String arg[]){
    Scanner input = new Scanner (System.in);
    float n1, n2, n3, media;
    System.out.println("Digite a sua 1° nota: ");
    n1 = input.nextFloat();
    System.out.println("Informe a sua 2° nota: ");
    n2 = input.nextFloat();
    System.out.println("Informe a sua 3° nota: ");
    n3 = input.nextFloat();
    media = (n1 + n2 + n3)/3;
    System.out.println("O valor da média deu: "+media);
}   
}
