
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ruan_a_alves
 */
public class Exercicio4 {
public static void main(String arg[]){
     Scanner input = new Scanner(System.in);
int numero;

System.out.println("Informe seu número");
numero = input.nextInt();
if ((numero % 2) == 0)
System.out.println("Seu número é par!");
else
System.out.println("Seu número é impar!");
 }
}
