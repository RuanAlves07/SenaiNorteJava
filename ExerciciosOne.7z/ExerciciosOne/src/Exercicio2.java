
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ruan_a_alves
 */
public class Exercicio2 {
   // public static void main(String arg[]){
        public void executar(){
        Scanner input = new Scanner(System.in);
        float num1, num2, add, sub, mult, div;
                System.out.println("Informe o 1° Número: ");
            num1 = input.nextFloat();
                System.out.println("Informe o 2° Número: ");
            num2 = input.nextFloat();
            add = num1 + num2;
            sub = num1 - num2;
            mult = num1 * num2;
            div = num1 / num2;
                System.out.println("Sua adição deu: "+add);
                System.out.println("Sua subtração deu: "+sub);
                System.out.println("Sua multiplicação deu: "+mult);
                System.out.println("Sua divisão deu: "+div);
       
    }

    
    
}
