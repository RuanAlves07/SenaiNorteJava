
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ruan_a_alves
 */
public class MenuPrincipal {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int opcao;
        
        do {
            System.out.println("Menu de opções");
            System.out.println("1 - EX1");
            System.out.println("2 - EX2");
            System.out.println("3 - EX3");
            System.out.println("4 - sair");
            System.out.println("escolha uma opção: ");
            opcao = input.nextInt();
            
            switch (opcao){
                case 1:
                    Exercicio1 exercicio1 = new Exercicio1();
                    exercicio1.executar();
                    break;
                case 2:
                    Exercicio2 exercicio2 = new Exercicio2();
                    exercicio2.executar();
                    break;
                case 3:
                    Exercicio3 exercicio3 = new Exercicio3();
                    exercicio3.executar();
                    break;
                case 4:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("opção invalida!");
            }
        } while (opcao != 0);
        
        input.close();
    }
    
}
