
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ruan_a_alves
 */
public class Exercicio3 {
 //public static void main(String arg[]){
     public void executar(){
     Scanner input = new Scanner(System.in);
   
 float Celsius, Fahrenheit;    
     
     System.out.println("Porfavor, informe os Celsius 'ºC' ");
     Celsius = input.nextFloat();
     Fahrenheit = (Celsius * 9/5)+32;
     System.out.println("A atual temperatura em Fahrenheit é em: "+Fahrenheit);
 }   

    
}
