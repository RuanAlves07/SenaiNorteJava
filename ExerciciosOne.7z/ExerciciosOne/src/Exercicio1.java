
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ruan_a_alves
 */
public class Exercicio1 {
    //public static void main(String [] args){
        public void executar(){
        Scanner input = new Scanner (System.in);
        String nome; 
        int idade;
            System.out.println("Porfavor, me informe seu nome: ");
        nome = input.nextLine();
            System.out.println("Porfavor, insira a sua idade: ");
        idade = input.nextInt();
        System.out.println("Seja bem vindo!");
        System.out.println("Seu nome é " +nome+" e você tem "+idade+" anos.");
        
                
    }

     {
        
    }
}
