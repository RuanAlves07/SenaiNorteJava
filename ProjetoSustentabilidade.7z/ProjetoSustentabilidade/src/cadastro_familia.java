
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author isaac_s_souza
 */
public class cadastro_familia extends javax.swing.JFrame {
    public cadastro_familia() {
        initComponents();
    }
    
    public void excluir_cliente(){
      DefaultTableModel model = (DefaultTableModel)jTabela.getModel();
      int selecteRow = jTabela.getSelectedRow();
      
      if(selecteRow != -1){
          int confirm = JOptionPane.showConfirmDialog(
                  this,
                  "Deseja realmente excluir?",
                  "comfirmação de Exclusão",
                  JOptionPane.YES_NO_OPTION);
          if(confirm == JOptionPane.YES_NO_OPTION){
              model.removeRow(selecteRow);
              
          }else {
              JOptionPane.showMessageDialog(this,"selecione um cliente:");
          }
          
      }
}
    @SuppressWarnings("unchecked")
    
    public void cadastro(){
        String nome = jlNome.getText();
        String banho = jtBanho.getText();
        String mes = (String)jtMes.getSelectedItem();
      
        double Minutos = 0.49;
        double tempo = Double.parseDouble(banho);
        double gasto = Minutos * tempo;    
        
        double MinutosL = 12;
        double TempoL = Double.parseDouble(banho);
        double litros = TempoL * MinutosL;       
        
        DefaultTableModel model = (DefaultTableModel) jTabela.getModel();
        model.addRow(new Object[]{nome,banho,litros,"R$"+gasto,mes});
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jltitulo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jlNome = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTabela = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jtConfirmar = new javax.swing.JButton();
        jtLimpar = new javax.swing.JButton();
        jtExcluir = new javax.swing.JButton();
        jtBanho = new javax.swing.JTextField();
        jtMes = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setPreferredSize(new java.awt.Dimension(600, 400));

        jltitulo.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        jltitulo.setText("Gastos de agua da familia");

        jLabel1.setText("Insira o Nome:");

        jLabel2.setText("Insira o tempo gasto no banho (min): ");

        jTabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Tempo no banho", "Total de litros", "Total gastos", "Mês "
            }
        ));
        jScrollPane1.setViewportView(jTabela);

        jLabel3.setText("Insira o mês:");

        jtConfirmar.setText("CONFIRMAR");
        jtConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtConfirmarActionPerformed(evt);
            }
        });

        jtLimpar.setText("LIMPAR");
        jtLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtLimparActionPerformed(evt);
            }
        });

        jtExcluir.setText("EXCLUIR");
        jtExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtExcluirActionPerformed(evt);
            }
        });

        jtMes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(73, 73, 73)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(175, 175, 175)
                                .addComponent(jltitulo))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(123, 123, 123)
                                .addComponent(jtConfirmar)))
                        .addGap(0, 65, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jtLimpar)
                                .addGap(61, 61, 61)
                                .addComponent(jtExcluir))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jlNome, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel2))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jtMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtBanho, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jltitulo)
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jlNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jtBanho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jtMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtConfirmar)
                    .addComponent(jtLimpar)
                    .addComponent(jtExcluir))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jtConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtConfirmarActionPerformed
        cadastro();
    }//GEN-LAST:event_jtConfirmarActionPerformed

    private void jtLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtLimparActionPerformed
       
        jlNome.setText("");
        jtBanho.setText("");
        
    }//GEN-LAST:event_jtLimparActionPerformed

    private void jtExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtExcluirActionPerformed
        excluir_cliente();
    }//GEN-LAST:event_jtExcluirActionPerformed

    public static void main(String args[]) {    
        
   
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new cadastro_familia().setVisible(true);
            }
        });
    }

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTabela;
    private javax.swing.JTextField jlNome;
    private javax.swing.JLabel jltitulo;
    private javax.swing.JTextField jtBanho;
    private javax.swing.JButton jtConfirmar;
    private javax.swing.JButton jtExcluir;
    private javax.swing.JButton jtLimpar;
    private javax.swing.JComboBox<String> jtMes;
    // End of variables declaration//GEN-END:variables
}
